## var와 dynamic
String name = '준장'; 
var friend = '준혁';  // 타입 추론
dynamic friend = '진우';  friend = 102; 타입 변경 가능

## 타입 캐스팅과 num
Java는 큰 타입이 작은 타입을 명시적으로 타입 캐스팅하지 않아도 자동으로 타입 캐스팅이 되지만 Dart의 경우 타입 캐스팅을 해야 한다.
int n = 34; double m = n; // Error: Compilation failed.
int n = 34; double m = n as double

num 같은 경우 int와 double 형식을 둘 다 받을 수 있기 때문에 온도 데이터, 키와 몸무게 데이터 등 int와 double 타입의 데이터를 구분 없이 받아야 할 때 사용한다.
num a = 34; num b = 34.8;

## **final과 const**
final과 const 모두 한번 선언하면 값을 변경할 수 없다.
final로 정의한 값은 런타임에서 정의된 값으로 설정할 수 있지만 const의 경우 정의한 값은 런타임에서 정의된 값으로 설정할 수 없다. 런타임에서 호출될 때마다 결과 값이 달라지는 Date.now() 메서드를 사용하여 결과를 확인해보자.
// funal로 정의한 값은 런타임에서 정의된 값을 설정할 수 있다.
final c = DateTime.now(); 
// const로 정의한 값은 런타임에서 정의된 값을 설정할 수 없다. 
const d = DateTime.now(); // Error: Compilation failed.

## **스프레드 연산자**
스프레드 연산자 . . . 는 collection을 펼쳐주거나 다른 collection을 삽입할 때 사용된다.
// 스프레드 연산자(...) var e = [1,2,3]; var f = [...e, 4, 5];

## **함수 선언**
함수를 선언할 때 함수의 형태는 => 함수명 (매개변수){ retrun 반환 값; }으로 정의된다. 
매개변수의 타입은 dynamic으로 추론되기 때문에 자료형을 명시할 필요 없다.\
addNumber(num1, num2){ return num1 + num2; } 
print(addNumber(1, 3)); // 출력 : 4 
print(addNuver("ab","cd")); // 출력 : abcd

## **선택 매개변수**
선택 매개변수는 함수를 정의할 때 {}로 감싼 매개변수를 선택적으로 사용할 수 있게끔 하는 것이다. 이런 매개변수를 Named Parameter라고도 불린다.
addNumber(num1, {num2}){ 
	return num1 + num2; 
} 
print(addNumber(1, num2 : 3)); // 출력 : 4 
print(addNumber(num2 : 3)); // error : 필수 매개변수를 작성하지 않음. print(addNumber(1)); // error : num2 = null 이기 때문에 연산을 하지 못함.

## **비동기 처리(Future, async, await)**
개발을 하다 보면 기능을 백그라운드에서 실행해야 하는 경우가 생긴다. 그럴 때마다 쓰는 것이 비동기인데 비동기 처리는 동기 처리가 모두 다 끝난 뒤에 이루어진다. 간단한 프로그램을 구현할 때는 처리 시간이 짧아도 되므로 동기 처리 방식을 사용해도 되지만 프로그램이 무거워수록 비동기 처리 방식은 필수적으로 사용해야 한다.

Future는 어떤 작업 결과값을 나중에 받기로 약속하는 것으로 요청한 작업의 결과를 기다리지 않고 바로 다음 작업을 진행한다. 그 후 작업이 완료되면 결과값을 받는 방식으로 비동기 처리가 실행된다.
void main(){ 
	print("시작"); 
	networkRequset(); 
	print("끝"); 
} 

Future networkRequset(){ 
	return Future.delayed(Duration(seconds : 3)); 
}

void main(){ 
	print("시작"); 
	networkRequset(); 
	print("끝"); 
} 

Future networkRequset() async{ 
	await Future.delayed(Duration(seconds : 1)); 
	print("1"); 
	await Future.delayed(Duration(seconds : 1)); 
	print("2"); 
	await Future.delayed(Duration(seconds : 1)); 
	print("3"); 
	await Future.delayed(Duration(seconds : 1)); 
	print("4"); 
	return; 
}

## **클래스**
클래스를 선언할 때 클래스의 형태는 => class 클래스명{멤버 변수, 멤버 함수 }으로 정의된다
클래스를 사용하기 위해서는 객체를 생성해야 한다. Java에서는 객체 생성 시 new 키워드를 사용하지만 Dart에서는 기본적으로 생략 한다.
void main(){ 
	var student = Person(); 
	student.name = "동현"; 
	print(student.getName()); // 출력 : 동현 
} 
class Person 
{ 
	var name; 
	var age; 
	getName(){ return name; } 
}

Java에서 Private과 같은 역할을 Dart에서는 _ 을 붙여 Private을 정의한다. 또 Java에서 Private은 클래스 안에서만 접근 가능하지만 Dart에서는 클래스가 정의된 파일에서 Private 변수에 접근할 수 있다.
void main(){  
  var student = Person();  
  student.name = "동현";  
  print(student.getName()); // 출력 : 동현종용  
  
}  
  
class Person {  
  var name;  
  var age;  
  var _teacher = "종용";  

  getName(){  
    return name + _teacher;  
  }  
}

## **null safety**
null safety란 null에게서 안전한 프로그램 코드를 작성하는 것을 의미한다. 쉽게 생각해서 코드가 실행되면서 예상치 못한 null을 대응하는 것이라고 생각하면 될 것 같다.

null safety는 nullable과 non- nullable로 나뉜다. 이렇게 구분되는 이유는 null 값을 대입할 수 있냐 없냐의 차이로 nullable은 null을 대입할 수 있는 것이고 non- nullable은 null을 대입할 수 없는 것이다. Dart 언어의 변수는 기본적으로 non- nullable로 선언되는 것이며 만약 nullable로 선언하고자 한다면 타입명 뒤에 ? 를 작성해주면 된다.
int g = 10;  
g = null; // Error: Compilation failed.  
  
int? h = 10;  
h = null; // 성공

위 코드를 보게 되면 변수 g, h 모두 int 타입으로 선언되었지만 h의 경우 int 뒤에 ? 를 작성하였기 때문에 null 값으로도 대입이 가능한 nullable로 선언되었다. null safety는 int 타입뿐만 아니라 모든 타입에 적용된다.
nullable 변수를 non- nullable 변수에 에러 없이 값을 넣을 수 도 있다.
! 를 작성하여 절대 null 값을 넣지 않을 거라는 것을 명시해주면 된다.


-   non- nullable 변수는 선언과 동시에 초기값을 주어야 한다. Dart 언어에서 변수를 선언할 때 초기값을 주지 않으면 null로 초기화된다. 하지만 non -nullable 은 null 받을 수 없기 때문에 에러가 나오게 된다. 따라서 non- nullable 변수는 선언과 동시에 초기값을 주어야 한다.
- var 타입은 nullable로 선언할 수 없다. 위에서 설명했듯이 var 타입은 타입 추론이 가능하므로 nullable과 non- nullable 도 자동으로 추론된다
- dynamic 타입에서의 null safety는 의미가 없다. dynamic 타입은 대입되는 값을 한정하지 않겠다는 의미로 모든 타입의 데이터가 대입될 수 있다. 이 모든 타입에는 nullable도 포함되므로 dynamic 타입으로 선언되는 것 자체가 nullable로 선언되는 것이다.
	var a1 = 10; // int + non- nullable  
	var a2 = null; // dynamic + nullable  
	var a3; // dynamic + nullable  
	var? a4 = null; // Error: Compilation failed.