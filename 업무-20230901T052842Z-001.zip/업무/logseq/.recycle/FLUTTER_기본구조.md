*  main()
	* runApp()
	* void main()  => runApp(MyApp()); // 프로그램을 실행할 때 MyApp 부터 실행하겠어!
- class MyApp extends StatelessWidget {}
	- StatelessWidget : 화면변화X
	- StatefulWidget : 화면변화O
		- MaterialApp() 을 리턴
			- Material 디자인 테마를 사용할 수 있고 MaterialApp이란 앱으로서 기능을 할 수 있도록 도와주는 뼈대라고 생각하면 좋을 거 같다.
			- home은 앱이 실행될 때 표실할 화면의 함수를 호출하거나 작성하는 것으로 위 코드에서는 MyWidget() 함수를 호출하는 것을 확인할 수 있다.
- class MyWidget extends StatelessWidget {}
	이제 앱이 실행될 때 표시할 화면을 구성할 차례이다.
	Scaffold는 구성된 앱에서 디자인적인 부분을 도와주는 뼈대라고 생각하면 좋을 것 같다. Scaffold 안에 다양한 위젯을 배치할 수 있다. 
	appbar에 AppBar 위젯을 가져와 타이틀에 텍스트 위젯을 가져와 타이틀의 이름을 지정해준다.
	앱의 body 부분에는 Container 위젯을 가져와 크기를 조정하고 색을 입혔다.
