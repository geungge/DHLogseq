## Hello World
- MyApp의 home  MyHomePage -> Scaffold / AppBar / title


## StatefulWidget
* stfl 을 타이핑해서 엔터 누르면 기본 위젯이 생성
* class 와 extends 사이에  Name typing (네모박스에 넣어야)
	* 모든이름이 같이 변경된다
* MyApp에서  StatefulWidget으로 string을 넘기고 StatefulWidget에서 표시형식을 결정하여 MyApp으로 넘겨 Title 표시하기
	* MyApp/home  HelloPage('Hello World')
	* HelloPage - String title 생성
	* _HelloPageState에서 Text 를 넘기기
	* 